"""
report_generator.py
--------------------
Generates a professional PDF threat intelligence report for a completed
email scan, using ReportLab.
"""

import os
from datetime import datetime
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, ListFlowable, ListItem
)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
REPORTS_DIR = os.path.join(BASE_DIR, "reports")

THREAT_COLORS = {
    "Safe": colors.HexColor("#2ecc71"),
    "Low": colors.HexColor("#f1c40f"),
    "Medium": colors.HexColor("#e67e22"),
    "High": colors.HexColor("#e74c3c"),
    "Critical": colors.HexColor("#8e0000"),
}


def generate_pdf_report(scan_record: dict) -> str:
    os.makedirs(REPORTS_DIR, exist_ok=True)
    filename = f"CyberShield_Report_{scan_record.get('id', 'scan')}_{datetime.utcnow().strftime('%Y%m%d%H%M%S')}.pdf"
    filepath = os.path.join(REPORTS_DIR, filename)

    doc = SimpleDocTemplate(filepath, pagesize=A4,
                             topMargin=20 * mm, bottomMargin=15 * mm,
                             leftMargin=18 * mm, rightMargin=18 * mm)
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle("TitleStyle", parent=styles["Title"], textColor=colors.HexColor("#0d1b2a"))
    heading_style = ParagraphStyle("HeadingStyle", parent=styles["Heading2"], textColor=colors.HexColor("#0d1b2a"),
                                    spaceBefore=12, spaceAfter=6)
    normal = styles["Normal"]

    story = []
    story.append(Paragraph("CyberShield &ndash; Threat Intelligence Report", title_style))
    story.append(Paragraph("Phishing Email Analysis &amp; Threat Detection Platform", styles["Italic"]))
    story.append(Spacer(1, 10))

    threat_level = scan_record.get("threat_level", "Unknown")
    risk_score = scan_record.get("risk_score", 0)
    color = THREAT_COLORS.get(threat_level, colors.grey)

    summary_data = [
        ["Scan Date", scan_record.get("timestamp", datetime.utcnow().isoformat())],
        ["Sender", scan_record.get("sender") or "N/A"],
        ["Subject", scan_record.get("subject") or "N/A"],
        ["Risk Score", f"{risk_score} / 100"],
        ["Threat Level", threat_level],
        ["AI Prediction", f"{scan_record.get('ml_label', 'N/A').title()} ({scan_record.get('ml_confidence', 0)*100:.1f}% confidence)"],
    ]
    table = Table(summary_data, colWidths=[110, 340])
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#0d1b2a")),
        ("TEXTCOLOR", (0, 0), (0, -1), colors.white),
        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
        ("BACKGROUND", (1, 4), (1, 4), color),
        ("TEXTCOLOR", (1, 4), (1, 4), colors.white),
        ("FONTNAME", (1, 4), (1, 4), "Helvetica-Bold"),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("FONTSIZE", (0, 0), (-1, -1), 9.5),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
    ]))
    story.append(table)
    story.append(Spacer(1, 14))

    story.append(Paragraph("Risk Factors &amp; Reasons", heading_style))
    reasons = scan_record.get("reasons", [])
    if reasons:
        items = [ListItem(Paragraph(r, normal)) for r in reasons]
        story.append(ListFlowable(items, bulletType="bullet"))
    else:
        story.append(Paragraph("No significant risk factors detected.", normal))

    story.append(Paragraph("Security Recommendations", heading_style))
    recs = scan_record.get("recommendations", [])
    if recs:
        items = [ListItem(Paragraph(r, normal)) for r in recs]
        story.append(ListFlowable(items, bulletType="bullet"))
    else:
        story.append(Paragraph("No specific recommendations.", normal))

    urls = scan_record.get("url_analyses", [])
    if urls:
        story.append(Paragraph("URL Security Analysis", heading_style))
        url_data = [["Domain", "Protocol", "Risk Rating", "Score"]]
        for u in urls[:15]:
            url_data.append([u.get("domain", ""), u.get("protocol", ""), u.get("risk_rating", ""), str(u.get("risk_score", ""))])
        url_table = Table(url_data, colWidths=[200, 70, 90, 60])
        url_table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1b263b")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
            ("FONTSIZE", (0, 0), (-1, -1), 8.5),
        ]))
        story.append(url_table)

    whois_analyses = scan_record.get("whois_analyses", [])
    if whois_analyses:
        story.append(Paragraph("WHOIS Domain Reconnaissance (python-whois)", heading_style))
        whois_data = [["Domain", "Registered On", "Age (days)", "Registrar", "Status"]]
        for w in whois_analyses[:10]:
            status = "Lookup unavailable" if w.get("error") else ("Newly Registered" if w.get("is_new_domain") else "Established")
            whois_data.append([
                w.get("domain", ""),
                w.get("creation_date") or "N/A",
                str(w.get("domain_age_days")) if w.get("domain_age_days") is not None else "N/A",
                w.get("registrar") or "N/A",
                status,
            ])
        whois_table = Table(whois_data, colWidths=[110, 80, 60, 110, 90])
        whois_table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1b263b")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
            ("FONTSIZE", (0, 0), (-1, -1), 8),
        ]))
        story.append(whois_table)
        story.append(Spacer(1, 10))

    story.append(Spacer(1, 16))
    story.append(Paragraph(
        "Generated automatically by CyberShield &ndash; Phishing Email Analysis &amp; Threat Detection Platform. "
        "This report is intended for security awareness and educational purposes.",
        styles["Italic"]))

    doc.build(story)
    return filepath
