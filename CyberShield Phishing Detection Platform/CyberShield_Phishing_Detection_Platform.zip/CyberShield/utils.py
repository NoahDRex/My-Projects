"""
utils.py
--------
Core analysis engine for CyberShield - Phishing Email Analysis & Threat
Detection Platform.

Contains:
  - Email parsing (headers, body, urls, attachments, IPs, phone numbers)
  - URL security analysis (protocol, domain, TLD, shorteners, IP-based URLs)
  - Email header analyzer (SPF, DKIM, DMARC, Return-Path / Reply-To / From
    mismatch, Received chain)
  - Phishing indicator / social-engineering pattern detection
  - Rule based + ML combined risk scoring engine
"""

import re
import email
import base64
import socket
from email import policy
from email.parser import Parser, BytesParser
from urllib.parse import urlparse
from datetime import datetime, timezone

try:
    import whois as whois_lib
    WHOIS_AVAILABLE = True
except ImportError:
    WHOIS_AVAILABLE = False

# --------------------------------------------------------------------------
# Static reference data used by the heuristics engine
# --------------------------------------------------------------------------

SUSPICIOUS_TLDS = {
    "zip", "xyz", "top", "click", "gq", "tk", "ml", "cf", "ga", "work",
    "loan", "win", "review", "party", "date", "faith", "download", "info",
}

URL_SHORTENERS = {
    "bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly", "is.gd", "buff.ly",
    "adf.ly", "cutt.ly", "rebrand.ly", "shorte.st",
}

KNOWN_BRANDS = [
    "paypal", "amazon", "apple", "microsoft", "google", "netflix", "bankofamerica",
    "chase", "wellsfargo", "facebook", "instagram", "linkedin", "dropbox", "irs",
]

URGENCY_WORDS = [
    "urgent", "immediately", "action required", "suspended", "verify your account",
    "limited time", "act now", "final notice", "restricted", "locked", "expire",
    "within 24 hours", "confirm your identity", "unusual activity", "unauthorized",
]

CREDENTIAL_REQUEST_WORDS = [
    "password", "otp", "one-time password", "ssn", "social security", "pin code",
    "card number", "cvv", "bank account", "login credentials", "username and password",
]

CRYPTO_WORDS = [
    "bitcoin", "crypto", "wallet address", "btc", "ethereum", "double your",
    "investment opportunity", "usdt",
]

FAKE_LOGIN_WORDS = [
    "click here to login", "verify your account", "confirm your password",
    "sign in to continue", "update your billing", "reactivate your account",
]

MISSPELLED_BRAND_PATTERNS = [
    (r"payp[a4]l", "paypal"),
    (r"amaz[o0]n", "amazon"),
    (r"micr[o0]s[o0]ft", "microsoft"),
    (r"g[o0]{2}gle", "google"),
    (r"[a4]pple[- ]?id", "apple"),
    (r"bank[o0]f[a4]merica", "bankofamerica"),
    (r"netfl[i1]x", "netflix"),
]

IP_URL_PATTERN = re.compile(r"https?://(\d{1,3}\.){3}\d{1,3}")
URL_PATTERN = re.compile(r"(https?://[^\s\"'<>\)]+)", re.IGNORECASE)
IP_PATTERN = re.compile(r"\b(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\b")
PHONE_PATTERN = re.compile(r"(\+?\d{1,3}[-.\s]?)?(\(?\d{2,4}\)?[-.\s]?){2,4}\d{3,4}")
EMAIL_PATTERN = re.compile(r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+")
HTML_TAG_PATTERN = re.compile(r"<[^>]+>")
SCRIPT_PATTERN = re.compile(r"<script.*?>.*?</script>", re.IGNORECASE | re.DOTALL)
BASE64_PATTERN = re.compile(r"(?:[A-Za-z0-9+/]{40,}={0,2})")


# --------------------------------------------------------------------------
# Email parsing
# --------------------------------------------------------------------------

def parse_raw_email(raw_text: str) -> dict:
    """
    Parses a raw email (with or without full RFC822 headers) that has been
    pasted into the scanner. Falls back gracefully when only the body text
    is supplied (no headers present).
    """
    raw_text = raw_text.strip()
    result = {
        "from": None,
        "to": None,
        "subject": None,
        "date": None,
        "return_path": None,
        "reply_to": None,
        "received_chain": [],
        "spf": None,
        "dkim": None,
        "dmarc": None,
        "body": raw_text,
        "has_headers": False,
    }

    looks_like_headers = bool(re.search(r"^(From|To|Subject|Received|Date):", raw_text, re.MULTILINE))
    result["has_headers"] = looks_like_headers

    if looks_like_headers:
        try:
            msg = Parser(policy=policy.default).parsestr(raw_text)
            result["from"] = msg.get("From")
            result["to"] = msg.get("To")
            result["subject"] = msg.get("Subject")
            result["date"] = msg.get("Date")
            result["return_path"] = msg.get("Return-Path")
            result["reply_to"] = msg.get("Reply-To")
            result["received_chain"] = msg.get_all("Received") or []

            auth_results = msg.get("Authentication-Results", "") or ""
            result["spf"] = _extract_auth_field(auth_results, "spf")
            result["dkim"] = _extract_auth_field(auth_results, "dkim")
            result["dmarc"] = _extract_auth_field(auth_results, "dmarc")

            # Extract body text
            if msg.is_multipart():
                body_parts = []
                for part in msg.walk():
                    ctype = part.get_content_type()
                    if ctype in ("text/plain", "text/html"):
                        try:
                            body_parts.append(part.get_content())
                        except Exception:
                            pass
                result["body"] = "\n".join(body_parts) if body_parts else raw_text
            else:
                try:
                    result["body"] = msg.get_content()
                except Exception:
                    result["body"] = raw_text
        except Exception:
            # Fall back to raw text if parsing fails
            result["body"] = raw_text
    else:
        # No headers -- try to sniff a From:/Subject:-style line anyway
        from_match = re.search(r"from[:\-]\s*(.+)", raw_text, re.IGNORECASE)
        subj_match = re.search(r"subject[:\-]\s*(.+)", raw_text, re.IGNORECASE)
        if from_match:
            result["from"] = from_match.group(1).strip().splitlines()[0]
        if subj_match:
            result["subject"] = subj_match.group(1).strip().splitlines()[0]

    return result


def _extract_auth_field(auth_header: str, field: str) -> str:
    match = re.search(rf"{field}=(\w+)", auth_header, re.IGNORECASE)
    return match.group(1).lower() if match else "none"


def extract_iocs(text: str, headers: dict) -> dict:
    """Extract Indicators of Compromise: urls, domains, ips, emails, phones, attachments, scripts."""
    urls = list(dict.fromkeys(URL_PATTERN.findall(text)))
    domains = list(dict.fromkeys([urlparse(u).netloc for u in urls if urlparse(u).netloc]))
    ips = list(dict.fromkeys(IP_PATTERN.findall(text)))
    emails_found = list(dict.fromkeys(EMAIL_PATTERN.findall(text)))
    phones = list(dict.fromkeys([p.strip() for p in PHONE_PATTERN.findall(text) if isinstance(p, str)]))
    phones = [p for p in re.findall(r"\+?\d[\d\-.\s()]{8,}\d", text)]
    scripts_found = bool(SCRIPT_PATTERN.search(text))
    html_found = bool(HTML_TAG_PATTERN.search(text))
    base64_blobs = BASE64_PATTERN.findall(text)
    decoded_samples = []
    for blob in base64_blobs[:3]:
        try:
            decoded = base64.b64decode(blob + "===").decode("utf-8", errors="ignore")
            if decoded.isprintable() and len(decoded) > 3:
                decoded_samples.append(decoded[:120])
        except Exception:
            continue

    attachments = []
    attach_matches = re.findall(r"([\w,\s-]+\.(?:exe|zip|rar|scr|js|vbs|docm|xlsm|pdf|html|jar))", text, re.IGNORECASE)
    attachments.extend(list(dict.fromkeys(attach_matches)))

    return {
        "urls": urls,
        "domains": domains,
        "ips": ips,
        "emails": emails_found,
        "phones": list(dict.fromkeys(phones))[:10],
        "attachments": attachments,
        "has_scripts": scripts_found,
        "has_html": html_found,
        "base64_blobs_count": len(base64_blobs),
        "decoded_samples": decoded_samples,
    }


# --------------------------------------------------------------------------
# URL security analysis
# --------------------------------------------------------------------------

def analyze_url(url: str) -> dict:
    parsed = urlparse(url)
    domain = parsed.netloc.lower()
    tld = domain.split(".")[-1] if "." in domain else ""
    is_ip_based = bool(IP_URL_PATTERN.match(url))
    is_shortener = any(short in domain for short in URL_SHORTENERS)
    is_https = parsed.scheme == "https"
    suspicious_tld = tld in SUSPICIOUS_TLDS
    url_length = len(url)
    is_long_url = url_length > 75

    misspelled_brand = None
    for pattern, brand in MISSPELLED_BRAND_PATTERNS:
        if re.search(pattern, domain) and brand not in domain:
            misspelled_brand = brand
            break
        if re.search(pattern, domain) and not domain.startswith(brand) and brand in domain and domain != f"www.{brand}.com":
            # e.g. paypal-secure-login.com contains 'paypal' but isn't the real domain
            if not domain.endswith(f"{brand}.com"):
                misspelled_brand = brand

    risk_points = 0
    reasons = []
    if not is_https:
        risk_points += 15
        reasons.append("URL does not use HTTPS encryption")
    if is_ip_based:
        risk_points += 30
        reasons.append("URL uses a raw IP address instead of a domain name")
    if is_shortener:
        risk_points += 20
        reasons.append("URL uses a link shortening service, which can hide the true destination")
    if suspicious_tld:
        risk_points += 20
        reasons.append(f"URL uses a suspicious top-level domain (.{tld})")
    if is_long_url:
        risk_points += 10
        reasons.append("URL is unusually long, a common obfuscation technique")
    if misspelled_brand:
        risk_points += 25
        reasons.append(f"Domain appears to impersonate the brand '{misspelled_brand}'")

    risk_points = min(risk_points, 100)

    if risk_points >= 60:
        rating = "Critical"
    elif risk_points >= 40:
        rating = "High"
    elif risk_points >= 20:
        rating = "Medium"
    elif risk_points > 0:
        rating = "Low"
    else:
        rating = "Safe"

    return {
        "url": url,
        "domain": domain,
        "protocol": parsed.scheme or "unknown",
        "tld": tld,
        "is_https": is_https,
        "is_ip_based": is_ip_based,
        "is_shortener": is_shortener,
        "suspicious_tld": suspicious_tld,
        "url_length": url_length,
        "is_long_url": is_long_url,
        "misspelled_brand": misspelled_brand,
        "risk_score": risk_points,
        "risk_rating": rating,
        "reasons": reasons,
    }


def analyze_all_urls(urls: list) -> list:
    return [analyze_url(u) for u in urls]


# --------------------------------------------------------------------------
# WHOIS domain reconnaissance (Ethical Hacking / OSINT tool: python-whois)
# --------------------------------------------------------------------------
#
# WHOIS lookups are a standard passive-reconnaissance technique used by
# ethical hackers / SOC analysts to investigate a suspicious domain before
# deciding whether to block or escalate it. A domain that was registered
# only days or weeks ago is one of the strongest known signals of a
# phishing campaign, since attackers frequently spin up throwaway domains
# for a single campaign and abandon them shortly after.

WHOIS_LOOKUP_TIMEOUT_SECONDS = 6
NEW_DOMAIN_THRESHOLD_DAYS = 180  # domains younger than ~6 months are flagged


def _first_date(value):
    """whois libraries sometimes return a list of dates; normalize to one."""
    if isinstance(value, list):
        value = value[0] if value else None
    if isinstance(value, datetime):
        if value.tzinfo is not None:
            value = value.replace(tzinfo=None)
        return value
    return None


def analyze_domain_whois(domain: str) -> dict:
    """
    Runs a WHOIS lookup on a domain extracted from the email and returns
    registration age, registrar, and country, along with a risk contribution
    if the domain is newly registered (a classic phishing red flag).
    """
    result = {
        "domain": domain,
        "lookup_success": False,
        "creation_date": None,
        "registrar": None,
        "country": None,
        "domain_age_days": None,
        "is_new_domain": False,
        "error": None,
        "risk_points": 0,
        "reason": None,
    }

    if not domain or not WHOIS_AVAILABLE:
        result["error"] = "WHOIS lookup unavailable"
        return result

    # Strip port/credentials if present, keep bare registrable-looking domain
    clean_domain = domain.split(":")[0].split("@")[-1]

    old_timeout = socket.getdefaulttimeout()
    try:
        socket.setdefaulttimeout(WHOIS_LOOKUP_TIMEOUT_SECONDS)
        record = whois_lib.whois(clean_domain)
        creation = _first_date(getattr(record, "creation_date", None))

        result["lookup_success"] = creation is not None or bool(getattr(record, "registrar", None))
        result["registrar"] = getattr(record, "registrar", None)
        result["country"] = getattr(record, "country", None)

        if creation:
            age_days = (datetime.utcnow() - creation).days
            result["creation_date"] = creation.strftime("%Y-%m-%d")
            result["domain_age_days"] = age_days
            if age_days < NEW_DOMAIN_THRESHOLD_DAYS:
                result["is_new_domain"] = True
                result["risk_points"] = 25
                result["reason"] = (
                    f"Domain '{clean_domain}' was registered only {age_days} days ago "
                    f"(< {NEW_DOMAIN_THRESHOLD_DAYS} days) — newly registered domains "
                    f"are frequently used in phishing campaigns"
                )
    except Exception as exc:
        result["error"] = f"{type(exc).__name__}: {exc}"
    finally:
        socket.setdefaulttimeout(old_timeout)

    return result


def analyze_all_domains_whois(domains: list, max_lookups: int = 5) -> list:
    """Runs WHOIS on a bounded number of unique domains to keep scans fast."""
    unique_domains = list(dict.fromkeys(d for d in domains if d))
    return [analyze_domain_whois(d) for d in unique_domains[:max_lookups]]


# --------------------------------------------------------------------------
# Email header analysis
# --------------------------------------------------------------------------

def analyze_headers(parsed_email: dict) -> dict:
    findings = []
    risk_points = 0

    spf = (parsed_email.get("spf") or "none").lower()
    dkim = (parsed_email.get("dkim") or "none").lower()
    dmarc = (parsed_email.get("dmarc") or "none").lower()

    if spf not in ("pass",):
        risk_points += 15
        findings.append(f"SPF check result: {spf} (expected 'pass')")
    if dkim not in ("pass",):
        risk_points += 15
        findings.append(f"DKIM check result: {dkim} (expected 'pass')")
    if dmarc not in ("pass",):
        risk_points += 15
        findings.append(f"DMARC check result: {dmarc} (expected 'pass')")

    from_addr = _extract_email_address(parsed_email.get("from"))
    reply_to = _extract_email_address(parsed_email.get("reply_to"))
    return_path = _extract_email_address(parsed_email.get("return_path"))

    from_domain = from_addr.split("@")[-1] if from_addr and "@" in from_addr else None
    reply_domain = reply_to.split("@")[-1] if reply_to and "@" in reply_to else None
    return_domain = return_path.split("@")[-1] if return_path and "@" in return_path else None

    reply_to_mismatch = bool(reply_domain and from_domain and reply_domain != from_domain)
    return_path_mismatch = bool(return_domain and from_domain and return_domain != from_domain)

    if reply_to_mismatch:
        risk_points += 20
        findings.append(f"Reply-To domain ({reply_domain}) does not match From domain ({from_domain})")
    if return_path_mismatch:
        risk_points += 20
        findings.append(f"Return-Path domain ({return_domain}) does not match From domain ({from_domain})")

    received_chain = parsed_email.get("received_chain") or []
    received_count = len(received_chain)

    return {
        "spf": spf,
        "dkim": dkim,
        "dmarc": dmarc,
        "from_address": from_addr,
        "reply_to": reply_to,
        "return_path": return_path,
        "from_domain": from_domain,
        "reply_to_mismatch": reply_to_mismatch,
        "return_path_mismatch": return_path_mismatch,
        "received_hops": received_count,
        "received_chain": received_chain,
        "risk_points": min(risk_points, 100),
        "findings": findings,
    }


def _extract_email_address(header_value):
    if not header_value:
        return None
    match = EMAIL_PATTERN.search(header_value)
    return match.group(0).lower() if match else None


# --------------------------------------------------------------------------
# Phishing indicator / social engineering detection
# --------------------------------------------------------------------------

def detect_phishing_indicators(text: str) -> dict:
    lower_text = text.lower()
    indicators = []

    def has_any(words):
        return [w for w in words if w in lower_text]

    urgency_hits = has_any(URGENCY_WORDS)
    credential_hits = has_any(CREDENTIAL_REQUEST_WORDS)
    crypto_hits = has_any(CRYPTO_WORDS)
    fake_login_hits = has_any(FAKE_LOGIN_WORDS)

    if urgency_hits:
        indicators.append({
            "type": "Urgency / Pressure Tactics",
            "detail": f"Detected urgency language: {', '.join(urgency_hits[:5])}",
            "weight": 15,
        })
    if credential_hits:
        indicators.append({
            "type": "Credential / Sensitive Data Request",
            "detail": f"Requests sensitive information: {', '.join(credential_hits[:5])}",
            "weight": 25,
        })
    if crypto_hits:
        indicators.append({
            "type": "Cryptocurrency Scam Pattern",
            "detail": f"Detected crypto scam language: {', '.join(crypto_hits[:5])}",
            "weight": 20,
        })
    if fake_login_hits:
        indicators.append({
            "type": "Fake Login / Call-to-Action",
            "detail": f"Detected fake login prompts: {', '.join(fake_login_hits[:5])}",
            "weight": 20,
        })

    misspelled_brands_found = []
    for pattern, brand in MISSPELLED_BRAND_PATTERNS:
        if re.search(pattern, lower_text):
            misspelled_brands_found.append(brand)
    if misspelled_brands_found:
        indicators.append({
            "type": "Brand Impersonation",
            "detail": f"Possible impersonation of: {', '.join(sorted(set(misspelled_brands_found)))}",
            "weight": 20,
        })

    total_weight = sum(i["weight"] for i in indicators)
    return {
        "indicators": indicators,
        "indicator_count": len(indicators),
        "score": min(total_weight, 100),
    }


# --------------------------------------------------------------------------
# Combined risk scoring engine
# --------------------------------------------------------------------------

def compute_risk_score(header_analysis: dict, url_analyses: list, indicator_analysis: dict,
                        ml_prediction: dict, iocs: dict, whois_analyses: list = None) -> dict:
    """
    Combines rule-based heuristics with the ML model's prediction to produce
    a final 0-100 risk score and threat level, along with human readable
    reasons and recommendations.
    """
    whois_analyses = whois_analyses or []

    # Rule-based component (weighted average of sub-scores)
    header_score = header_analysis["risk_points"]
    url_score = max([u["risk_score"] for u in url_analyses], default=0)
    indicator_score = indicator_analysis["score"]
    whois_score = max([w["risk_points"] for w in whois_analyses], default=0)

    rule_based_score = (header_score * 0.25) + (url_score * 0.30) + (indicator_score * 0.30) + (whois_score * 0.15)

    # ML component
    ml_label = ml_prediction.get("label", "legitimate")
    ml_confidence = ml_prediction.get("confidence", 0.0)
    ml_score_map = {"phishing": 100, "spam": 60, "legitimate": 5}
    ml_score = ml_score_map.get(ml_label, 20) * ml_confidence + ml_score_map.get(ml_label, 20) * 0.2

    # Extra IOC based bumps
    ioc_bonus = 0
    reasons = []
    if iocs.get("has_scripts"):
        ioc_bonus += 15
        reasons.append("Email body contains embedded <script> code")
    if iocs.get("base64_blobs_count", 0) > 0:
        ioc_bonus += 10
        reasons.append("Email contains suspicious Base64-encoded content")
    if len(iocs.get("attachments", [])) > 0:
        risky_ext = any(a.lower().endswith((".exe", ".scr", ".js", ".vbs", ".jar")) for a in iocs["attachments"])
        if risky_ext:
            ioc_bonus += 25
            reasons.append("Email contains a potentially dangerous executable attachment")
        else:
            ioc_bonus += 5
            reasons.append("Email contains file attachments — verify before opening")

    # Final blended score: 55% rule-based, 35% ML, 10% IOC bonus (capped)
    final_score = (rule_based_score * 0.55) + (min(ml_score, 100) * 0.35) + min(ioc_bonus, 100) * 0.10
    final_score = round(min(max(final_score, 0), 100), 1)

    if final_score >= 80:
        threat_level = "Critical"
    elif final_score >= 60:
        threat_level = "High"
    elif final_score >= 35:
        threat_level = "Medium"
    elif final_score >= 15:
        threat_level = "Low"
    else:
        threat_level = "Safe"

    # Compile all reasons
    all_reasons = []
    all_reasons.extend(header_analysis.get("findings", []))
    for u in url_analyses:
        for r in u["reasons"]:
            all_reasons.append(f"[{u['domain']}] {r}")
    for w in whois_analyses:
        if w.get("reason"):
            all_reasons.append(f"[WHOIS] {w['reason']}")
    for ind in indicator_analysis.get("indicators", []):
        all_reasons.append(f"{ind['type']}: {ind['detail']}")
    all_reasons.extend(reasons)
    if not all_reasons:
        all_reasons.append("No significant phishing indicators detected")

    recommendations = generate_recommendations(threat_level, header_analysis, url_analyses, indicator_analysis, iocs, whois_analyses)

    return {
        "risk_score": final_score,
        "threat_level": threat_level,
        "rule_based_score": round(rule_based_score, 1),
        "ml_score": round(ml_score, 1),
        "ioc_bonus": round(min(ioc_bonus, 100), 1),
        "reasons": all_reasons,
        "recommendations": recommendations,
        "ml_prediction": ml_prediction,
    }


def generate_recommendations(threat_level, header_analysis, url_analyses, indicator_analysis, iocs, whois_analyses=None):
    whois_analyses = whois_analyses or []
    recs = []
    if threat_level in ("Critical", "High"):
        recs.append("Do NOT click any links or download attachments from this email.")
        recs.append("Do not reply with any personal, financial, or login information.")
        recs.append("Report this email to your IT/Security team or use 'Report Phishing' in your mail client.")
        recs.append("Delete the email after reporting, and block the sender.")
    elif threat_level == "Medium":
        recs.append("Treat this email with caution — verify the sender through a separate, trusted channel.")
        recs.append("Do not click links directly; navigate to the official website manually instead.")
        recs.append("Hover over links to inspect the true destination URL before clicking.")
    elif threat_level == "Low":
        recs.append("Exercise general caution — this email has minor suspicious characteristics.")
        recs.append("Verify sender identity if the email requests any action.")
    else:
        recs.append("No strong phishing indicators found; email appears safe.")
        recs.append("Continue to follow standard email security hygiene.")

    if header_analysis.get("reply_to_mismatch") or header_analysis.get("return_path_mismatch"):
        recs.append("The Reply-To/Return-Path mismatch suggests the sender address may be spoofed.")
    if any(u["is_shortener"] for u in url_analyses):
        recs.append("Avoid clicking shortened URLs; expand them first using a URL un-shortening tool.")
    if iocs.get("has_scripts"):
        recs.append("This email contains active script content — do not open in a browser-rendered mail client.")
    if any(w.get("is_new_domain") for w in whois_analyses):
        recs.append("One or more linked domains were registered very recently (WHOIS lookup) — treat as high risk even if content looks legitimate.")

    return recs
