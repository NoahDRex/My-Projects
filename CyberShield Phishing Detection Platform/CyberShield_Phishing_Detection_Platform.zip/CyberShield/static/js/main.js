// CyberShield main.js - shared chart rendering utilities

const THREAT_COLORS = {
  Safe: '#2ecc71',
  Low: '#f1c40f',
  Medium: '#e67e22',
  High: '#e74c3c',
  Critical: '#ff2d55',
};

function renderRiskGauge(canvasId, score, threatLevel) {
  const el = document.getElementById(canvasId);
  if (!el) return;
  const color = THREAT_COLORS[threatLevel] || '#00ffc8';

  new Chart(el, {
    type: 'doughnut',
    data: {
      labels: ['Risk', 'Remaining'],
      datasets: [{
        data: [score, 100 - score],
        backgroundColor: [color, 'rgba(255,255,255,0.06)'],
        borderWidth: 0,
        circumference: 270,
        rotation: 225,
        cutout: '75%',
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: { display: false },
        tooltip: { enabled: false },
      }
    },
    plugins: [{
      id: 'centerText',
      afterDraw(chart) {
        const { ctx, width, height } = chart;
        ctx.save();
        ctx.font = "bold 28px 'Share Tech Mono', monospace";
        ctx.fillStyle = color;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(score, width / 2, height / 2 - 5);
        ctx.font = "12px 'Share Tech Mono', monospace";
        ctx.fillStyle = '#7d93a3';
        ctx.fillText('RISK SCORE', width / 2, height / 2 + 20);
        ctx.restore();
      }
    }]
  });
}

function renderDashboardCharts(threatLevelData, mlLabelData, byDayData) {
  const threatCanvas = document.getElementById('threatLevelChart');
  if (threatCanvas) {
    const labels = Object.keys(threatLevelData);
    const values = Object.values(threatLevelData);
    new Chart(threatCanvas, {
      type: 'doughnut',
      data: {
        labels,
        datasets: [{
          data: values,
          backgroundColor: labels.map(l => THREAT_COLORS[l] || '#00ffc8'),
        }]
      },
      options: {
        plugins: { legend: { position: 'bottom', labels: { color: '#d7ecf5' } } }
      }
    });
  }

  const mlCanvas = document.getElementById('mlLabelChart');
  if (mlCanvas) {
    const labels = Object.keys(mlLabelData);
    const values = Object.values(mlLabelData);
    const colorMap = { legitimate: '#2ecc71', spam: '#f1c40f', phishing: '#e74c3c' };
    new Chart(mlCanvas, {
      type: 'bar',
      data: {
        labels,
        datasets: [{
          label: 'Emails',
          data: values,
          backgroundColor: labels.map(l => colorMap[l] || '#00ffc8'),
        }]
      },
      options: {
        plugins: { legend: { display: false } },
        scales: {
          x: { ticks: { color: '#d7ecf5' }, grid: { color: 'rgba(255,255,255,0.05)' } },
          y: { ticks: { color: '#d7ecf5' }, grid: { color: 'rgba(255,255,255,0.05)' } },
        }
      }
    });
  }

  const timeCanvas = document.getElementById('scansOverTimeChart');
  if (timeCanvas) {
    new Chart(timeCanvas, {
      type: 'line',
      data: {
        labels: byDayData.map(d => d.day),
        datasets: [{
          label: 'Scans per day',
          data: byDayData.map(d => d.count),
          borderColor: '#00ffc8',
          backgroundColor: 'rgba(0,255,200,0.15)',
          fill: true,
          tension: 0.35,
        }]
      },
      options: {
        plugins: { legend: { labels: { color: '#d7ecf5' } } },
        scales: {
          x: { ticks: { color: '#d7ecf5' }, grid: { color: 'rgba(255,255,255,0.05)' } },
          y: { ticks: { color: '#d7ecf5' }, grid: { color: 'rgba(255,255,255,0.05)' }, beginAtZero: true },
        }
      }
    });
  }
}
