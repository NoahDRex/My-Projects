"""
app.py
------
CyberShield - Phishing Email Analysis & Threat Detection Platform
Flask application entry point.

Run:
    python app.py

Then open http://127.0.0.1:5000 in your browser.
"""

import os
import json
from datetime import datetime

import joblib
from flask import (
    Flask, render_template, request, jsonify, send_file, redirect, url_for, flash
)

import utils
import database
from sample_emails import DEMO_SAMPLES
from report_generator import generate_pdf_report
from train_model import preprocess_text

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(BASE_DIR, "model", "phishing_model.pkl")
VECTORIZER_PATH = os.path.join(BASE_DIR, "model", "vectorizer.pkl")

app = Flask(__name__)
app.secret_key = "cybershield-dev-secret-key-change-in-production"

# --------------------------------------------------------------------------
# Model loading (auto-train on first run if missing)
# --------------------------------------------------------------------------
_model = None
_vectorizer = None


def load_model():
    """Loads the trained ML model & vectorizer, auto-training if not found."""
    global _model, _vectorizer
    if _model is not None and _vectorizer is not None:
        return _model, _vectorizer

    if not (os.path.exists(MODEL_PATH) and os.path.exists(VECTORIZER_PATH)):
        print("[CyberShield] No trained model found. Training now...")
        from train_model import train
        train()

    _model = joblib.load(MODEL_PATH)
    _vectorizer = joblib.load(VECTORIZER_PATH)
    return _model, _vectorizer


def ml_predict(text: str) -> dict:
    model, vectorizer = load_model()
    clean = preprocess_text(text)
    vec = vectorizer.transform([clean])
    probs = model.predict_proba(vec)[0]
    classes = model.classes_
    best_idx = probs.argmax()
    label = classes[best_idx]
    confidence = float(probs[best_idx])
    prob_map = {cls: float(p) for cls, p in zip(classes, probs)}
    return {"label": label, "confidence": confidence, "probabilities": prob_map}


# --------------------------------------------------------------------------
# Core scan pipeline (shared by scan route and demo mode)
# --------------------------------------------------------------------------

def run_full_scan(raw_email_text: str) -> dict:
    parsed = utils.parse_raw_email(raw_email_text)
    iocs = utils.extract_iocs(parsed["body"] or raw_email_text, parsed)
    header_analysis = utils.analyze_headers(parsed)
    url_analyses = utils.analyze_all_urls(iocs["urls"])
    indicator_analysis = utils.detect_phishing_indicators(raw_email_text)
    ml_prediction = ml_predict(parsed["body"] or raw_email_text)

    # WHOIS domain reconnaissance (ethical-hacking / OSINT tool: python-whois)
    # Requires outbound network access to WHOIS servers (port 43). If the
    # lookup fails (offline, firewalled, or rate-limited) it degrades
    # gracefully and simply contributes zero risk points.
    whois_analyses = utils.analyze_all_domains_whois(iocs["domains"])

    risk_result = utils.compute_risk_score(
        header_analysis, url_analyses, indicator_analysis, ml_prediction, iocs, whois_analyses
    )

    full_report = {
        "parsed_email": parsed,
        "iocs": iocs,
        "header_analysis": header_analysis,
        "url_analyses": url_analyses,
        "indicator_analysis": indicator_analysis,
        "whois_analyses": whois_analyses,
        "risk_result": risk_result,
    }

    scan_record = {
        "timestamp": datetime.utcnow().isoformat(timespec="seconds") + "Z",
        "sender": parsed.get("from") or "Unknown",
        "subject": parsed.get("subject") or "(no subject)",
        "risk_score": risk_result["risk_score"],
        "threat_level": risk_result["threat_level"],
        "ml_label": ml_prediction["label"],
        "ml_confidence": ml_prediction["confidence"],
        "url_count": len(iocs["urls"]),
        "reasons": risk_result["reasons"],
        "recommendations": risk_result["recommendations"],
        "raw_email": raw_email_text,
        "full_report": full_report,
    }

    scan_id = database.save_scan(scan_record)
    scan_record["id"] = scan_id
    scan_record["full_report"] = full_report
    return scan_record


# --------------------------------------------------------------------------
# Routes
# --------------------------------------------------------------------------

@app.route("/")
def index():
    return render_template("index.html", demo_samples=DEMO_SAMPLES)


@app.route("/scan", methods=["POST"])
def scan():
    raw_email = request.form.get("email_content", "").strip()
    if not raw_email:
        flash("Please paste an email to scan.", "warning")
        return redirect(url_for("index"))

    scan_record = run_full_scan(raw_email)
    return redirect(url_for("view_report", scan_id=scan_record["id"]))


@app.route("/api/scan", methods=["POST"])
def api_scan():
    """JSON API endpoint for programmatic / AJAX scanning."""
    data = request.get_json(silent=True) or {}
    raw_email = data.get("email_content", "").strip()
    if not raw_email:
        return jsonify({"error": "email_content is required"}), 400
    scan_record = run_full_scan(raw_email)
    return jsonify({
        "id": scan_record["id"],
        "risk_score": scan_record["risk_score"],
        "threat_level": scan_record["threat_level"],
        "ml_label": scan_record["ml_label"],
        "ml_confidence": scan_record["ml_confidence"],
        "reasons": scan_record["reasons"],
        "recommendations": scan_record["recommendations"],
    })


@app.route("/demo/<sample_key>")
def demo_scan(sample_key):
    sample = DEMO_SAMPLES.get(sample_key)
    if not sample:
        flash("Unknown demo sample.", "danger")
        return redirect(url_for("index"))
    scan_record = run_full_scan(sample["content"])
    return redirect(url_for("view_report", scan_id=scan_record["id"]))


@app.route("/report/<int:scan_id>")
def view_report(scan_id):
    scan_record = database.get_scan(scan_id)
    if not scan_record:
        flash("Scan not found.", "danger")
        return redirect(url_for("index"))

    scan_record["reasons"] = json.loads(scan_record["reasons"] or "[]")
    scan_record["recommendations"] = json.loads(scan_record["recommendations"] or "[]")
    full_report = json.loads(scan_record["full_report"] or "{}")

    return render_template(
        "scan_result.html",
        scan=scan_record,
        report=full_report,
    )


@app.route("/report/<int:scan_id>/pdf")
def download_pdf(scan_id):
    scan_record = database.get_scan(scan_id)
    if not scan_record:
        flash("Scan not found.", "danger")
        return redirect(url_for("index"))

    scan_record["reasons"] = json.loads(scan_record["reasons"] or "[]")
    scan_record["recommendations"] = json.loads(scan_record["recommendations"] or "[]")
    full_report = json.loads(scan_record["full_report"] or "{}")
    scan_record["url_analyses"] = full_report.get("url_analyses", [])
    scan_record["whois_analyses"] = full_report.get("whois_analyses", [])

    filepath = generate_pdf_report(scan_record)
    return send_file(filepath, as_attachment=True, download_name=os.path.basename(filepath))


@app.route("/history")
def history():
    query = request.args.get("q", "")
    threat_level = request.args.get("threat_level", "")
    scans = database.search_scans(query=query, threat_level=threat_level)
    for s in scans:
        s["reasons"] = json.loads(s["reasons"] or "[]")
    return render_template("history.html", scans=scans, query=query, threat_level=threat_level)


@app.route("/history/<int:scan_id>/delete", methods=["POST"])
def delete_history(scan_id):
    database.delete_scan(scan_id)
    flash("Scan record deleted.", "success")
    return redirect(url_for("history"))


@app.route("/dashboard")
def dashboard():
    stats = database.get_stats()
    for s in stats["recent_scans"]:
        s["reasons"] = json.loads(s["reasons"] or "[]")
    return render_template("dashboard.html", stats=stats)


@app.route("/api/stats")
def api_stats():
    return jsonify(database.get_stats())


@app.errorhandler(404)
def not_found(e):
    return render_template("404.html"), 404


# --------------------------------------------------------------------------
# App bootstrap
# --------------------------------------------------------------------------

def bootstrap():
    database.init_db()
    load_model()


bootstrap()

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
