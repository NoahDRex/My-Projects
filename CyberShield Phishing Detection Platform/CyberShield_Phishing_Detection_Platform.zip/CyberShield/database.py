"""
database.py
------------
SQLite persistence layer for CyberShield.

Handles:
  - Schema creation
  - Storing scan results (scan history)
  - Searching / filtering scan history
  - Admin dashboard aggregate statistics
"""

import sqlite3
import os
import json
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "data", "cybershield.db")


def get_connection():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS scans (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            sender TEXT,
            subject TEXT,
            risk_score REAL,
            threat_level TEXT,
            ml_label TEXT,
            ml_confidence REAL,
            url_count INTEGER,
            reasons TEXT,
            recommendations TEXT,
            raw_email TEXT,
            full_report TEXT
        )
    """)
    conn.commit()
    conn.close()


def save_scan(record: dict) -> int:
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO scans
        (timestamp, sender, subject, risk_score, threat_level, ml_label,
         ml_confidence, url_count, reasons, recommendations, raw_email, full_report)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        record.get("timestamp", datetime.utcnow().isoformat()),
        record.get("sender"),
        record.get("subject"),
        record.get("risk_score"),
        record.get("threat_level"),
        record.get("ml_label"),
        record.get("ml_confidence"),
        record.get("url_count", 0),
        json.dumps(record.get("reasons", [])),
        json.dumps(record.get("recommendations", [])),
        record.get("raw_email", ""),
        json.dumps(record.get("full_report", {})),
    ))
    conn.commit()
    scan_id = cur.lastrowid
    conn.close()
    return scan_id


def get_scan(scan_id: int):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM scans WHERE id = ?", (scan_id,))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None


def search_scans(query: str = "", threat_level: str = "", limit: int = 200):
    conn = get_connection()
    cur = conn.cursor()
    sql = "SELECT * FROM scans WHERE 1=1"
    params = []
    if query:
        sql += " AND (sender LIKE ? OR subject LIKE ?)"
        params.extend([f"%{query}%", f"%{query}%"])
    if threat_level:
        sql += " AND threat_level = ?"
        params.append(threat_level)
    sql += " ORDER BY id DESC LIMIT ?"
    params.append(limit)
    cur.execute(sql, params)
    rows = cur.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_stats():
    conn = get_connection()
    cur = conn.cursor()

    cur.execute("SELECT COUNT(*) as c FROM scans")
    total = cur.fetchone()["c"]

    cur.execute("SELECT threat_level, COUNT(*) as c FROM scans GROUP BY threat_level")
    by_level = {r["threat_level"]: r["c"] for r in cur.fetchall()}

    cur.execute("SELECT ml_label, COUNT(*) as c FROM scans GROUP BY ml_label")
    by_label = {r["ml_label"]: r["c"] for r in cur.fetchall()}

    cur.execute("SELECT AVG(risk_score) as avg_score FROM scans")
    avg_score_row = cur.fetchone()
    avg_score = round(avg_score_row["avg_score"], 1) if avg_score_row["avg_score"] else 0

    cur.execute("""
        SELECT substr(timestamp, 1, 10) as day, COUNT(*) as c
        FROM scans GROUP BY day ORDER BY day DESC LIMIT 14
    """)
    by_day = [{"day": r["day"], "count": r["c"]} for r in cur.fetchall()]
    by_day.reverse()

    cur.execute("SELECT * FROM scans ORDER BY id DESC LIMIT 5")
    recent = [dict(r) for r in cur.fetchall()]

    conn.close()
    return {
        "total_scans": total,
        "by_threat_level": by_level,
        "by_ml_label": by_label,
        "avg_risk_score": avg_score,
        "by_day": by_day,
        "recent_scans": recent,
    }


def delete_scan(scan_id: int):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM scans WHERE id = ?", (scan_id,))
    conn.commit()
    conn.close()
