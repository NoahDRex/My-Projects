# 🛡️ CyberShield – Phishing Email Analysis & Threat Detection Platform

A full-stack, SOC-style (Security Operations Center) web application that analyzes
suspicious emails and identifies phishing indicators using a combination of
**rule-based heuristics** and a **machine learning classifier** (TF-IDF + Naive Bayes).

Built as a final-year Ethical Hacking mini project.

---

## ✨ Features

- **Futuristic SOC dashboard** — dark theme, animated matrix background, scan animation, risk gauge
- **Email scanner** — paste raw emails (with headers) or plain body text
- **Threat analysis** — extracts sender, subject, URLs, domains, IPs, attachments, phone numbers, embedded HTML/JavaScript, and Base64-encoded payloads
- **WHOIS domain reconnaissance (ethical hacking / OSINT tool)** — uses the `python-whois` library to look up domain registration date, registrar, and country for every domain linked in the email. Domains registered less than ~6 months ago are flagged as high-risk, since attackers commonly spin up disposable domains for a single phishing campaign. This is the same passive-recon technique real SOC analysts use before deciding whether to block or escalate a domain.
- **Phishing indicator detection** — fake logins, password/OTP/bank requests, crypto scams, urgency language, shortened URLs, suspicious domains, misspelled/impersonated brands
- **URL security analysis** — protocol (HTTP/HTTPS), domain, suspicious TLDs, IP-based URLs, URL length, risk rating
- **Email header analyzer** — SPF, DKIM, DMARC, Return-Path/Reply-To/From mismatch detection, Received chain hop count
- **Threat intelligence report** — composite 0–100 risk score, threat level (Safe/Low/Medium/High/Critical), reasons, and actionable recommendations
- **AI prediction** — Legitimate / Spam / Phishing classification combined with the rule-based score
- **Scan history** — stored in SQLite, searchable and filterable by sender/subject/threat level
- **PDF report export** — professional, downloadable threat report per scan
- **Admin dashboard** — aggregate statistics with Chart.js visualizations (threat distribution, AI label breakdown, scans-over-time)
- **Demo mode** — one-click sample phishing, spam, and legitimate emails

---

## 🧰 Technology Stack

| Layer          | Technology                                              |
|----------------|----------------------------------------------------------|
| Frontend       | HTML5, CSS3, JavaScript, Bootstrap 5, Chart.js, Font Awesome |
| Backend        | Python 3, Flask                                          |
| Database       | SQLite                                                    |
| Machine Learning | Scikit-learn (TF-IDF vectorizer + Multinomial Naive Bayes) |
| Ethical Hacking / OSINT Tool | **python-whois** — domain registration / age reconnaissance |
| Libraries      | pandas, numpy, requests, beautifulsoup4, reportlab, joblib |

---

## 📁 Project Structure

```
CyberShield/
├── app.py                  # Flask application & routes
├── train_model.py          # Trains the TF-IDF + Naive Bayes classifier
├── utils.py                # Email parsing, URL/header analysis, risk scoring engine
├── database.py             # SQLite persistence layer
├── report_generator.py     # PDF threat report generation (ReportLab)
├── sample_emails.py         # Demo-mode sample emails
├── requirements.txt
├── README.md
├── dataset/
│   ├── generate_dataset.py # Synthetic dataset generator
│   └── phishing_dataset.csv
├── model/                  # Trained model artifacts (auto-generated)
│   ├── phishing_model.pkl
│   ├── vectorizer.pkl
│   └── metrics.json
├── data/
│   └── cybershield.db      # SQLite database (auto-generated)
├── reports/                 # Generated PDF reports (auto-generated)
├── static/
│   ├── css/style.css
│   └── js/
│       ├── matrix.js
│       └── main.js
└── templates/
    ├── base.html
    ├── index.html
    ├── scan_result.html
    ├── history.html
    ├── dashboard.html
    └── 404.html
```

---

## 🚀 Setup & Installation

### 1. Create a virtual environment (recommended)
```bash
python3 -m venv venv
source venv/bin/activate      # On Windows: venv\Scripts\activate
```

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. (Optional) Regenerate the training dataset
A dataset is already included at `dataset/phishing_dataset.csv`. To regenerate it:
```bash
cd dataset
python generate_dataset.py
cd ..
```

### 4. Train the ML model
```bash
python train_model.py
```
This creates `model/phishing_model.pkl`, `model/vectorizer.pkl`, and `model/metrics.json`.

> **Note:** If you skip this step, `app.py` will automatically train the model
> on first run.

### 5. Run the application
```bash
python app.py
```

Open your browser to **http://127.0.0.1:5000**

---

## 🧪 Using Demo Mode

On the Scanner page, click any of the **Demo Mode** buttons (Phishing / Spam /
Legitimate) to instantly run a full analysis on a pre-built sample email —
no need to have a real suspicious email on hand.

---

## 📊 Risk Scoring Methodology

The final risk score (0–100) blends three components:

1. **Rule-based score (55%)** — weighted combination of email header analysis (SPF/DKIM/DMARC, mismatches), URL risk analysis (protocol, shorteners, suspicious TLDs, IP-based URLs, brand impersonation), **WHOIS domain-age reconnaissance**, and phishing indicator pattern matches (urgency, credential requests, crypto scams, fake login prompts).
2. **ML model score (35%)** — the TF-IDF + Naive Bayes classifier's predicted label (Legitimate / Spam / Phishing) and confidence.
3. **IOC bonus (10%)** — additional risk from embedded scripts, Base64-encoded payloads, and risky attachments.

> **Note on WHOIS lookups:** these require outbound network access to WHOIS servers (port 43). Corporate/campus/college networks and some cloud sandboxes block this port. If a lookup fails, it degrades gracefully — the report will show "Lookup unavailable" for that domain and the rest of the scan is unaffected. Run the app on a normal home/mobile-hotspot internet connection to see live WHOIS data.

Threat levels:

| Score   | Threat Level |
|---------|--------------|
| 80–100  | Critical     |
| 60–79   | High         |
| 35–59   | Medium       |
| 15–34   | Low          |
| 0–14    | Safe         |

---

## ⚠️ Disclaimer

This project is built for **educational purposes** as part of an Ethical
Hacking mini project curriculum. The synthetic training dataset and heuristic
rules are illustrative and are **not** a substitute for production-grade
threat intelligence or commercial anti-phishing solutions.

---

## 👤 Author

Developed as a final-year AIML engineering capstone/mini-project.
