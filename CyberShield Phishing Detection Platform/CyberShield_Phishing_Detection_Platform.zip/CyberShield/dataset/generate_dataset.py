"""
generate_dataset.py
--------------------
Generates a synthetic labeled dataset of email texts (Legitimate / Spam / Phishing)
used to train the CyberShield ML model (train_model.py).

In a real-world deployment this would be replaced by a public dataset such as
the Nazario Phishing Corpus or the Kaggle "Phishing Email Detection" dataset.
This generator produces a reasonably diverse, class-balanced dataset so the
demo model trains quickly and gives believable predictions offline.
"""

import csv
import random

random.seed(42)

PHISHING_TEMPLATES = [
    "Dear Customer, your account has been suspended. Click here to verify your identity immediately: {url}",
    "URGENT: Your {bank} account will be locked in 24 hours. Confirm your password and OTP now at {url}",
    "You have won a prize of ${amount}! Claim your reward now by entering your bank details: {url}",
    "Security Alert: Unusual sign-in activity detected. Verify your account at {url} or it will be permanently disabled.",
    "Your package could not be delivered. Pay a small customs fee at {url} to release your shipment.",
    "Action Required: Update your payment information within 24 hours to avoid suspension. {url}",
    "Congratulations! You have been selected to receive a free {item}. Confirm your shipping details and card info here: {url}",
    "We detected a problem with your billing information for your {service} subscription. Update now: {url}",
    "Your mailbox has exceeded its storage limit. Click {url} and login with your email password to upgrade.",
    "IRS Notice: You are eligible for a tax refund of ${amount}. Submit your SSN and bank account at {url}",
    "Final Notice: Your {bank} account access will be restricted. Verify OTP sent to your phone at {url}",
    "Bitcoin Investment Opportunity - Double your crypto in 24 hours! Send funds to wallet and login at {url}",
    "Your Apple ID has been locked for security reasons. Unlock now: {url}",
    "HR Department: Please review and sign the attached document urgently using your company password. {url}",
    "Your {service} password expires today. Click {url} to reset it before you lose access.",
]

SPAM_TEMPLATES = [
    "Buy cheap {item} now! 90% discount only today. Visit {url}",
    "Hot singles in your area want to meet you! Sign up free at {url}",
    "Lose 20 pounds in a week with this one weird trick! {url}",
    "Get rich quick working from home, earn ${amount} per day. {url}",
    "Limited time offer: Free {item} samples, just pay shipping. {url}",
    "Enlarge your business reach with our marketing list of 10 million emails. {url}",
    "Congratulations, you qualify for a low interest loan of ${amount}. Apply now {url}",
    "Cheap replica watches and designer bags available now. {url}",
    "Your search history says you need this {item}! Buy now at 50% off {url}",
    "Make money fast with this guaranteed investment scheme, no risk. {url}",
]

LEGITIMATE_TEMPLATES = [
    "Hi team, please find attached the minutes from yesterday's meeting regarding the {project} project.",
    "Hello, thank you for your order #{orderid}. Your {item} will be shipped within 3-5 business days.",
    "Dear {name}, your monthly statement for {service} is now available in your account dashboard.",
    "Hi, just checking in to see if you're free for a call next week to discuss the {project} proposal.",
    "Your subscription to {service} was renewed successfully. No action is required.",
    "Reminder: Your appointment with Dr. Smith is scheduled for next Tuesday at 10 AM.",
    "Hi, attached is the invoice for last month's consulting services. Let me know if you have questions.",
    "Welcome to {service}! Here is a quick guide to get started with your new account.",
    "Hello, the report you requested on {project} performance is attached to this email.",
    "Hi there, your flight booking confirmation for your upcoming trip is attached. Safe travels!",
    "Team, the sprint planning meeting for {project} has been moved to Thursday at 2 PM.",
    "Thank you for contacting support. Your ticket #{orderid} has been resolved.",
]

URLS = [
    "http://secure-login-update.com/verify",
    "http://192.168.44.12/login",
    "http://paypa1-secure.com/reset",
    "http://bit.ly/3xJ29Km",
    "http://amaz0n-support.net/account",
    "https://accounts.google.com/signin",
    "https://www.microsoft.com/en-us/account",
    "http://verify-bank0famerica.com",
    "https://tinyurl.com/2p8x9z",
    "http://appleid-unlock-secure.info",
]

BANKS = ["Chase", "Bank of America", "Wells Fargo", "HDFC Bank", "Citibank"]
ITEMS = ["iPhone 15", "laptop", "smartwatch", "gift card", "headphones"]
SERVICES = ["Netflix", "Amazon Prime", "Microsoft 365", "Spotify", "Dropbox"]
NAMES = ["Alex", "Priya", "John", "Maria", "Noah", "Sara"]
PROJECTS = ["Groundwater Prediction", "PPE Compliance", "Website Redesign", "Q3 Marketing"]

def fill(template):
    return template.format(
        url=random.choice(URLS),
        amount=random.choice([500, 1000, 2500, 10000, 250]),
        item=random.choice(ITEMS),
        bank=random.choice(BANKS),
        service=random.choice(SERVICES),
        name=random.choice(NAMES),
        project=random.choice(PROJECTS),
        orderid=random.randint(10000, 99999),
    )

def generate(n_per_class=60):
    rows = []
    for _ in range(n_per_class):
        rows.append((fill(random.choice(PHISHING_TEMPLATES)), "phishing"))
        rows.append((fill(random.choice(SPAM_TEMPLATES)), "spam"))
        rows.append((fill(random.choice(LEGITIMATE_TEMPLATES)), "legitimate"))
    random.shuffle(rows)
    return rows

if __name__ == "__main__":
    rows = generate(80)
    with open("phishing_dataset.csv", "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["text", "label"])
        writer.writerows(rows)
    print(f"Generated {len(rows)} rows -> phishing_dataset.csv")
