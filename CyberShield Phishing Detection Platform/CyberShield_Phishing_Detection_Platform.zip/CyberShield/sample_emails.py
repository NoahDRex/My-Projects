"""
sample_emails.py
-----------------
Sample emails used by CyberShield's Demo Mode so the platform can be
showcased instantly without needing a real suspicious email on hand.
"""

SAMPLE_PHISHING = """From: "Bank Security Team" <security@bankofamerica-verify.com>
To: victim@example.com
Reply-To: support@secure-alerts.net
Return-Path: <bounce@totally-different-domain.ru>
Subject: URGENT: Your Account Will Be Suspended in 24 Hours
Date: Mon, 27 Jul 2026 09:15:00 +0000
Authentication-Results: mx.example.com; spf=fail; dkim=fail; dmarc=fail

Dear Valued Customer,

We have detected unusual activity on your account. Your account access will
be permanently suspended within 24 hours unless you verify your identity
immediately.

Please click the link below and confirm your password and OTP to restore
access:

http://bankofamerica-secure-verify.tk/login?id=8231

If you do not verify within 24 hours, your funds will be frozen and your
account will be closed permanently. This is your final notice.

For your security, do not share this email with anyone.

Sincerely,
Bank of America Security Team
"""

SAMPLE_SPAM = """From: "Mega Deals" <offers@mega-deals-cheap.top>
To: victim@example.com
Subject: You Won't Believe This 90% Discount - Buy Now!
Date: Mon, 27 Jul 2026 11:02:00 +0000

Hey!!!

Amazing news! You qualify for a limited time 90% discount on designer
watches. Also get a chance to make $500 a day working from home with our
guaranteed investment scheme. Visit http://bit.ly/3xJ29Km now before the
offer ends!

Unsubscribe: http://mega-deals-cheap.top/unsub
"""

SAMPLE_LEGITIMATE = """From: "GitHub" <notifications@github.com>
To: developer@example.com
Subject: [example/repo] New comment on your issue #42
Date: Mon, 27 Jul 2026 14:30:00 +0000
Authentication-Results: mx.example.com; spf=pass; dkim=pass; dmarc=pass

Hi there,

@teammate commented on issue #42 in example/repo:

"Thanks for the PR, I've reviewed the changes and left a couple of small
suggestions inline. Overall this looks great!"

View it on GitHub:
https://github.com/example/repo/issues/42#comment

You are receiving this because you authored the thread.
"""

DEMO_SAMPLES = {
    "phishing": {
        "label": "Phishing Example",
        "description": "A fake bank security alert using urgency, credential requests, and a spoofed domain.",
        "content": SAMPLE_PHISHING,
    },
    "spam": {
        "label": "Spam Example",
        "description": "An unsolicited promotional email with too-good-to-be-true offers and shortened URLs.",
        "content": SAMPLE_SPAM,
    },
    "legitimate": {
        "label": "Legitimate Example",
        "description": "A normal GitHub notification email with passing SPF/DKIM/DMARC checks.",
        "content": SAMPLE_LEGITIMATE,
    },
}
