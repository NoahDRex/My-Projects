/* =========================================================
   AquaPredict - dashboard.js
   Renders all Chart.js visualizations on the Dashboard page.
   Expects these globals to already be defined by dashboard.html:
       distributions, correlation, modelComparison, featureImportance, historyData
   ========================================================= */

const GW_BLUE = "#0d6efd";
const GW_GREEN = "#198754";
const GW_TEAL = "#20c997";
const GW_WARN = "#ffc107";
const GW_RED = "#dc3545";

const palette = [GW_BLUE, GW_GREEN, GW_TEAL, GW_WARN, GW_RED, "#6f42c1"];

/* ---------------- Model Comparison Chart ---------------- */
(function renderModelComparison() {
    const ctx = document.getElementById("modelComparisonChart");
    if (!ctx || !modelComparison || modelComparison.length === 0) return;

    new Chart(ctx, {
        type: "bar",
        data: {
            labels: modelComparison.map((m) => m.name),
            datasets: [
                {
                    label: "R² Score",
                    data: modelComparison.map((m) => m.R2),
                    backgroundColor: modelComparison.map((_, i) => palette[i % palette.length]),
                    borderRadius: 8,
                },
            ],
        },
        options: {
            responsive: true,
            plugins: { legend: { display: false } },
            scales: { y: { beginAtZero: true, max: 1 } },
        },
    });
})();

/* ---------------- Feature Importance Chart ---------------- */
(function renderFeatureImportance() {
    const ctx = document.getElementById("featureImportanceChart");
    if (!ctx || !featureImportance) return;

    const entries = Object.entries(featureImportance)
        .filter(([, v]) => v > 0)
        .slice(0, 10);

    new Chart(ctx, {
        type: "bar",
        data: {
            labels: entries.map(([k]) => k),
            datasets: [
                {
                    label: "Importance",
                    data: entries.map(([, v]) => v),
                    backgroundColor: GW_GREEN,
                    borderRadius: 6,
                },
            ],
        },
        options: {
            indexAxis: "y",
            responsive: true,
            plugins: { legend: { display: false } },
            scales: { x: { beginAtZero: true } },
        },
    });
})();

/* ---------------- Correlation Heatmap (custom grid, no extra plugin needed) ---------------- */
(function renderHeatmap() {
    const container = document.getElementById("heatmapContainer");
    if (!container || !correlation) return;

    const labels = correlation.labels;
    const matrix = correlation.matrix;
    const n = labels.length;

    const table = document.createElement("table");
    table.style.borderCollapse = "collapse";
    table.style.width = "100%";
    table.style.fontSize = "0.72rem";

    // Header row
    const headRow = document.createElement("tr");
    headRow.appendChild(document.createElement("th"));
    labels.forEach((l) => {
        const th = document.createElement("th");
        th.innerText = l;
        th.style.padding = "4px";
        th.style.whiteSpace = "nowrap";
        th.style.fontWeight = "600";
        headRow.appendChild(th);
    });
    table.appendChild(headRow);

    for (let i = 0; i < n; i++) {
        const row = document.createElement("tr");
        const rowHead = document.createElement("th");
        rowHead.innerText = labels[i];
        rowHead.style.padding = "4px";
        rowHead.style.whiteSpace = "nowrap";
        rowHead.style.textAlign = "right";
        row.appendChild(rowHead);

        for (let j = 0; j < n; j++) {
            const val = matrix[i][j];
            const cell = document.createElement("td");
            cell.className = "heatmap-cell";
            cell.innerText = val.toFixed(2);
            cell.style.width = "48px";
            cell.style.height = "36px";
            cell.style.backgroundColor = correlationColor(val);
            row.appendChild(cell);
        }
        table.appendChild(row);
    }
    container.appendChild(table);
})();

function correlationColor(value) {
    // value ranges from -1 (red) through 0 (white) to +1 (blue/green)
    const abs = Math.abs(value);
    if (value >= 0) {
        const g = Math.round(150 + 105 * (1 - abs));
        return `rgb(${Math.round(255 - abs * 200)}, ${g}, ${Math.round(255 - abs * 60)})`;
    } else {
        const g = Math.round(150 + 105 * (1 - abs));
        return `rgb(${Math.round(255 - abs * 20)}, ${g}, ${Math.round(255 - abs * 200)})`;
    }
}

/* ---------------- Feature Distribution Chart (with dropdown selector) ---------------- */
let distributionChartInstance = null;
(function renderDistributionSelector() {
    const select = document.getElementById("distFeatureSelect");
    const ctx = document.getElementById("distributionChart");
    if (!select || !ctx || !distributions) return;

    Object.keys(distributions).forEach((key) => {
        const opt = document.createElement("option");
        opt.value = key;
        opt.innerText = key;
        select.appendChild(opt);
    });

    function draw(featureName) {
        const data = distributions[featureName];
        if (distributionChartInstance) distributionChartInstance.destroy();
        distributionChartInstance = new Chart(ctx, {
            type: "bar",
            data: {
                labels: data.labels,
                datasets: [
                    {
                        label: featureName,
                        data: data.counts,
                        backgroundColor: GW_BLUE,
                        borderRadius: 4,
                    },
                ],
            },
            options: {
                responsive: true,
                plugins: { legend: { display: false } },
                scales: { y: { beginAtZero: true } },
            },
        });
    }

    select.addEventListener("change", (e) => draw(e.target.value));
    // Draw the first feature by default
    const firstKey = Object.keys(distributions)[0];
    if (firstKey) draw(firstKey);
})();

/* ---------------- Prediction History Chart ---------------- */
(function renderHistoryChart() {
    const ctx = document.getElementById("historyChart");
    if (!ctx || !historyData || historyData.length === 0) return;

    new Chart(ctx, {
        type: "line",
        data: {
            labels: historyData.map((_, i) => `#${i + 1}`),
            datasets: [
                {
                    label: "Predicted Depth (ft)",
                    data: historyData.map((h) => h.prediction),
                    borderColor: GW_GREEN,
                    backgroundColor: "rgba(25, 135, 84, 0.15)",
                    fill: true,
                    tension: 0.3,
                    pointBackgroundColor: GW_GREEN,
                },
            ],
        },
        options: {
            responsive: true,
            plugins: { legend: { display: true } },
            scales: { y: { beginAtZero: true } },
        },
    });
})();
