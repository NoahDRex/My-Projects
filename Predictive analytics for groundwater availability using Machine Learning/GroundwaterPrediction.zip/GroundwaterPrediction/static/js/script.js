/* =========================================================
   AquaPredict - script.js
   Shared UI behaviors: dark mode toggle, small enhancements
   ========================================================= */

(function () {
    const DARK_MODE_KEY = "aquapredict_dark_mode";

    function applyDarkMode(isDark) {
        document.body.classList.toggle("dark-mode", isDark);
        const icon = document.getElementById("darkModeIcon");
        if (icon) {
            icon.classList.toggle("bi-moon-stars-fill", !isDark);
            icon.classList.toggle("bi-sun-fill", isDark);
        }
    }

    // Restore saved preference on page load (in-memory fallback if storage blocked)
    let savedPref = null;
    try {
        savedPref = window.localStorage.getItem(DARK_MODE_KEY);
    } catch (e) {
        savedPref = null;
    }
    if (savedPref === "true") applyDarkMode(true);

    const toggleBtn = document.getElementById("darkModeToggle");
    if (toggleBtn) {
        toggleBtn.addEventListener("click", function () {
            const isDark = !document.body.classList.contains("dark-mode");
            applyDarkMode(isDark);
            try {
                window.localStorage.setItem(DARK_MODE_KEY, isDark);
            } catch (e) {
                /* localStorage unavailable - dark mode still works for this page view */
            }
        });
    }
})();
