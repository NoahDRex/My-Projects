"""
app.py
------
Flask backend for the Groundwater Prediction System.

Routes:
    GET  /              -> Home page
    GET  /about          -> About page (dataset, models, workflow, developer)
    GET  /predict        -> Prediction form page (auto-generated inputs)
    POST /predict        -> Handle form submission, show result page
    GET  /dashboard       -> Dashboard page (charts: distributions, heatmap,
                              model comparison, prediction history)
    POST /api/predict     -> JSON API endpoint for predictions (used by JS/fetch)

Run:
    python app.py
Then open:
    http://127.0.0.1:5000
"""

import json
import os

import numpy as np
import pandas as pd
from flask import Flask, jsonify, render_template, request, session

from predict import predictor

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(BASE_DIR, "Colorado_Groundwater.csv")
COMPARISON_FILE = os.path.join(BASE_DIR, "model_comparison.json")

app = Flask(__name__)
app.secret_key = "groundwater-prediction-system-secret-key"  # Used only for session-based history


# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------
def model_is_ready() -> bool:
    """Check whether the trained model artifacts have been loaded successfully."""
    return predictor is not None


def get_dataset_sample(n=1500):
    """
    Load a sample of the dataset for dashboard charting.
    Sampling keeps the payload small and the page fast, while still being
    representative of the underlying distribution.
    """
    df = pd.read_csv(DATA_FILE)
    if len(df) > n:
        df = df.sample(n=n, random_state=42)
    return df


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------
@app.route("/")
def index():
    """Home page with hero section and project overview."""
    stats = predictor.metadata["dataset_stats"] if model_is_ready() else None
    best_model = predictor.metadata["best_model_name"] if model_is_ready() else "N/A"
    best_r2 = round(predictor.metadata["best_model_r2"] * 100, 2) if model_is_ready() else 0
    return render_template(
        "index.html", stats=stats, best_model=best_model, best_r2=best_r2
    )


@app.route("/about")
def about():
    """About page: dataset info, ML models used, workflow, developer info."""
    model_comparison = predictor.model_comparison if model_is_ready() else []
    metadata = predictor.metadata if model_is_ready() else None
    return render_template(
        "about.html", model_comparison=model_comparison, metadata=metadata
    )


@app.route("/predict", methods=["GET"])
def predict_form():
    """Render the prediction form with auto-generated input fields."""
    if not model_is_ready():
        return render_template(
            "predict.html",
            fields=[],
            error="Model artifacts not found. Please run 'python train_model.py' first.",
        )
    fields = predictor.get_form_fields()
    return render_template("predict.html", fields=fields, error=None)


@app.route("/predict", methods=["POST"])
def predict_submit():
    """Handle prediction form submission (standard HTML form, not JS fetch)."""
    if not model_is_ready():
        return render_template(
            "predict.html",
            fields=[],
            error="Model artifacts not found. Please run 'python train_model.py' first.",
        )

    fields = predictor.get_form_fields()
    raw_input = {f["name"]: request.form.get(f["name"], "") for f in fields}

    try:
        result = predictor.predict(raw_input)
    except ValueError as exc:
        return render_template("predict.html", fields=fields, error=str(exc))

    # Store last few predictions in session for the dashboard's
    # "Prediction History (current session only)" chart
    history = session.get("history", [])
    history.append(
        {
            "prediction": result["prediction"],
            "time": result["prediction_time"],
            "model": result["model_used"],
        }
    )
    session["history"] = history[-20:]  # keep only the last 20

    return render_template("result.html", result=result)


@app.route("/dashboard")
def dashboard():
    """Dashboard page with feature distributions, correlation heatmap, model comparison."""
    if not model_is_ready():
        return render_template(
            "dashboard.html",
            error="Model artifacts not found. Please run 'python train_model.py' first.",
        )

    df = get_dataset_sample()
    numeric_cols = predictor.metadata["numeric_columns"] + [predictor.metadata["target_column"]]

    # --- Feature distribution data (histograms computed server-side) ---
    distributions = {}
    for col in numeric_cols:
        counts, bin_edges = np.histogram(df[col].dropna(), bins=12)
        distributions[col] = {
            "labels": [f"{bin_edges[i]:.1f}" for i in range(len(bin_edges) - 1)],
            "counts": counts.tolist(),
        }

    # --- Correlation heatmap data ---
    corr = df[numeric_cols].corr().round(3)
    correlation = {
        "labels": corr.columns.tolist(),
        "matrix": corr.values.tolist(),
    }

    # --- Model comparison data ---
    model_comparison = predictor.model_comparison

    # --- Prediction history (session only) ---
    history = session.get("history", [])

    # --- Dataset statistics ---
    stats = predictor.metadata["dataset_stats"]
    feature_importance = predictor.metadata["feature_importance"]

    return render_template(
        "dashboard.html",
        distributions=json.dumps(distributions),
        correlation=json.dumps(correlation),
        model_comparison=model_comparison,
        model_comparison_json=json.dumps(model_comparison),
        history=history,
        history_json=json.dumps(history),
        stats=stats,
        feature_importance=feature_importance,
        feature_importance_json=json.dumps(feature_importance),
        error=None,
    )


@app.route("/api/predict", methods=["POST"])
def api_predict():
    """JSON API endpoint - accepts a JSON body of feature values, returns a JSON prediction."""
    if not model_is_ready():
        return jsonify({"error": "Model artifacts not found. Run train_model.py first."}), 503

    raw_input = request.get_json(silent=True) or {}
    try:
        result = predictor.predict(raw_input)
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400

    history = session.get("history", [])
    history.append(
        {
            "prediction": result["prediction"],
            "time": result["prediction_time"],
            "model": result["model_used"],
        }
    )
    session["history"] = history[-20:]

    return jsonify(result)


@app.errorhandler(404)
def not_found(e):
    return render_template("index.html", stats=None, best_model="N/A", best_r2=0), 404


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
