"""
build_dataset.py
-----------------
Builds the unified 'Colorado_Groundwater.csv' dataset used by the
Groundwater Prediction System.

The raw source files come from the Colorado Division of Water Resources (CODWR)
groundwater monitoring network:

    SITE_INFO.csv   -> static metadata about each monitoring well/site
                        (location, well depth, aquifer, county, well type, etc.)
    WATERLEVEL.csv  -> time-series groundwater level measurements for each site

This script joins the two files on the shared 'SiteNo' key, engineers a
handful of useful features (Year / Month of measurement), drops columns that
would leak the answer or add no predictive value, and writes out a clean,
single CSV file: Colorado_Groundwater.csv

Target column: 'GroundwaterLevel_ft'
    -> Depth to Water Below Land Surface, in feet.
       (A LOWER value means the water table is closer to the surface /
        more available groundwater. A HIGHER value means the water table
        is deeper / less accessible groundwater.)

Run:
    python build_dataset.py
"""

import pandas as pd
import numpy as np

SITE_INFO_FILE = "SITE_INFO.csv"
WATERLEVEL_FILE = "WATERLEVEL.csv"
OUTPUT_FILE = "Colorado_Groundwater.csv"

# Columns to keep from SITE_INFO.csv (well/site metadata)
SITE_COLUMNS = [
    "SiteNo",
    "DecLatVa",          # Latitude
    "DecLongVa",         # Longitude
    "AltVa",             # Land surface altitude (ft)
    "WellDepth",         # Depth of the well (ft)
    "NatAqfrDesc",       # National aquifer description (categorical)
    "CountyNm",          # County name (categorical)
    "LocalAquiferName",  # Local aquifer name (categorical)
    "SiteType",          # Site type (categorical)
    "AquiferType",       # Confined / Unconfined (categorical)
    "WlWellType",        # Well type code (categorical)
    "WlWellPurpose",     # Purpose of well: irrigation, domestic, etc. (categorical)
]

# Columns to keep from WATERLEVEL.csv (measurements)
WATERLEVEL_COLUMNS = [
    "SiteNo",
    "Time",
    "Observation Method",
    "Depth to Water Below Land Surface in ft.",
]


def build_dataset():
    print("Loading SITE_INFO.csv ...")
    sites = pd.read_csv(SITE_INFO_FILE, low_memory=False)
    sites = sites[SITE_COLUMNS].copy()

    print("Loading WATERLEVEL.csv ...")
    levels = pd.read_csv(WATERLEVEL_FILE, low_memory=False)
    levels = levels[WATERLEVEL_COLUMNS].copy()

    # Drop rows with no target value
    levels = levels.dropna(subset=["Depth to Water Below Land Surface in ft."])

    # Parse the measurement timestamp into Year / Month features
    levels["Time"] = pd.to_datetime(levels["Time"], errors="coerce", utc=True)
    levels["Year"] = levels["Time"].dt.year
    levels["Month"] = levels["Time"].dt.month
    levels = levels.drop(columns=["Time"])

    # Rename target column to something clean
    levels = levels.rename(
        columns={"Depth to Water Below Land Surface in ft.": "GroundwaterLevel_ft"}
    )
    levels = levels.rename(columns={"Observation Method": "ObservationMethod"})

    print("Merging site metadata with water level measurements ...")
    merged = levels.merge(sites, on="SiteNo", how="left")

    # Drop the raw site identifier - it's a unique key, not a useful predictive
    # feature (using it directly would let a model "memorize" specific wells).
    merged = merged.drop(columns=["SiteNo"])

    # Basic sanity filtering: remove clearly invalid / impossible values
    merged = merged[merged["GroundwaterLevel_ft"].between(-50, 2000)]
    merged = merged[merged["Year"].between(1900, 2100)]

    # Reorder so the target column is last
    cols = [c for c in merged.columns if c != "GroundwaterLevel_ft"] + ["GroundwaterLevel_ft"]
    merged = merged[cols]

    merged.to_csv(OUTPUT_FILE, index=False)
    print(f"Saved {OUTPUT_FILE} with shape {merged.shape}")
    print("\nColumn overview:")
    print(merged.dtypes)
    print("\nSample rows:")
    print(merged.head())


if __name__ == "__main__":
    build_dataset()
