"""
predict.py
----------
Reusable prediction helper module for the Groundwater Prediction System.

This module is responsible for:
    - Loading the trained model, scaler, label encoders and metadata once
    - Building a properly-ordered / properly-encoded feature vector from
      raw user input (a dict of {feature_name: value})
    - Running inference and returning a clean result dictionary

It is imported by app.py (Flask backend) but is fully self-contained and
could also be run/tested independently.
"""

import json
import os
from datetime import datetime

import joblib
import numpy as np

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

MODEL_FILE = os.path.join(BASE_DIR, "model.pkl")
SCALER_FILE = os.path.join(BASE_DIR, "scaler.pkl")
ENCODER_FILE = os.path.join(BASE_DIR, "encoder.pkl")
METADATA_FILE = os.path.join(BASE_DIR, "model_metadata.json")
COMPARISON_FILE = os.path.join(BASE_DIR, "model_comparison.json")


class GroundwaterPredictor:
    """Loads model artifacts once and exposes a simple `.predict(input_dict)` API."""

    def __init__(self):
        self.model = None
        self.scaler = None
        self.encoders = None
        self.metadata = None
        self.model_comparison = None
        self.load_artifacts()

    def load_artifacts(self):
        """Load the trained model + preprocessing objects + metadata from disk."""
        missing = [
            p
            for p in [MODEL_FILE, SCALER_FILE, ENCODER_FILE, METADATA_FILE]
            if not os.path.exists(p)
        ]
        if missing:
            raise FileNotFoundError(
                "Missing trained model artifacts: "
                f"{missing}. Please run `python train_model.py` first."
            )

        self.model = joblib.load(MODEL_FILE)
        self.scaler = joblib.load(SCALER_FILE)
        self.encoders = joblib.load(ENCODER_FILE)

        with open(METADATA_FILE) as f:
            self.metadata = json.load(f)

        if os.path.exists(COMPARISON_FILE):
            with open(COMPARISON_FILE) as f:
                self.model_comparison = json.load(f)

    def get_form_fields(self):
        """
        Build a list of field definitions describing every input the
        prediction form needs to collect, in the correct feature order.
        Used by the Flask app to auto-generate the prediction form.
        """
        fields = []
        numeric_ranges = self.metadata["numeric_ranges"]
        categorical_options = self.metadata["categorical_options"]

        for col in self.metadata["numeric_columns"]:
            rng = numeric_ranges[col]
            fields.append(
                {
                    "name": col,
                    "label": self._prettify(col),
                    "type": "number",
                    "min": round(rng["min"], 2),
                    "max": round(rng["max"], 2),
                    "default": round(rng["mean"], 2),
                }
            )

        for col in self.metadata["categorical_columns"]:
            options = categorical_options[col]
            fields.append(
                {
                    "name": col,
                    "label": self._prettify(col),
                    "type": "select",
                    "options": options,
                    "default": options[0] if options else "",
                }
            )
        return fields

    @staticmethod
    def _prettify(col_name: str) -> str:
        """Turn a raw column name like 'DecLatVa' into a friendly label."""
        friendly_map = {
            "DecLatVa": "Latitude",
            "DecLongVa": "Longitude",
            "AltVa": "Land Surface Altitude (ft)",
            "WellDepth": "Well Depth (ft)",
            "WlWellType": "Well Type Code",
            "WlWellPurpose": "Well Purpose Code",
            "Year": "Measurement Year",
            "Month": "Measurement Month",
            "ObservationMethod": "Observation Method",
            "NatAqfrDesc": "National Aquifer",
            "CountyNm": "County",
            "LocalAquiferName": "Local Aquifer",
            "SiteType": "Site Type",
            "AquiferType": "Aquifer Type (Confined/Unconfined)",
        }
        return friendly_map.get(col_name, col_name)

    def validate_input(self, raw_input: dict):
        """
        Validate raw form input. Returns (cleaned_dict, list_of_errors).
        Numeric fields must parse as floats and fall within a sane range.
        Categorical fields must be one of the known trained categories.
        """
        errors = []
        cleaned = {}
        numeric_ranges = self.metadata["numeric_ranges"]
        categorical_options = self.metadata["categorical_options"]

        for col in self.metadata["numeric_columns"]:
            value = raw_input.get(col, None)
            if value is None or str(value).strip() == "":
                errors.append(f"'{self._prettify(col)}' is required.")
                continue
            try:
                value = float(value)
            except (TypeError, ValueError):
                errors.append(f"'{self._prettify(col)}' must be a number.")
                continue

            rng = numeric_ranges[col]
            # Allow a small buffer (10%) beyond observed training range
            span = rng["max"] - rng["min"] if rng["max"] != rng["min"] else 1
            buffer = span * 0.1
            if value < rng["min"] - buffer or value > rng["max"] + buffer:
                errors.append(
                    f"'{self._prettify(col)}' should be between "
                    f"{rng['min']:.2f} and {rng['max']:.2f}."
                )
                continue
            cleaned[col] = value

        for col in self.metadata["categorical_columns"]:
            value = raw_input.get(col, None)
            if value is None or str(value).strip() == "":
                errors.append(f"'{self._prettify(col)}' is required.")
                continue
            if value not in categorical_options[col]:
                errors.append(f"'{self._prettify(col)}' has an invalid selection.")
                continue
            cleaned[col] = value

        return cleaned, errors

    def predict(self, raw_input: dict):
        """
        Run the full prediction pipeline on a dict of raw form input.
        Returns a result dict with prediction, model name, timestamp, and status.
        Raises ValueError with a message if validation fails.
        """
        cleaned, errors = self.validate_input(raw_input)
        if errors:
            raise ValueError(" | ".join(errors))

        feature_columns = self.metadata["feature_columns"]
        row = []
        for col in feature_columns:
            value = cleaned[col]
            if col in self.encoders:
                le = self.encoders[col]
                value = int(le.transform([str(value)])[0])
            row.append(value)

        import pandas as pd

        X = pd.DataFrame([row], columns=feature_columns)
        X_scaled = self.scaler.transform(X)
        prediction = float(self.model.predict(X_scaled)[0])

        # Determine a friendly status message based on predicted depth-to-water
        if prediction < 20:
            status = "Shallow water table - high groundwater availability"
            status_level = "success"
        elif prediction < 60:
            status = "Moderate depth - normal groundwater availability"
            status_level = "info"
        elif prediction < 150:
            status = "Deep water table - limited groundwater availability"
            status_level = "warning"
        else:
            status = "Very deep water table - low groundwater availability"
            status_level = "danger"

        return {
            "prediction": round(prediction, 2),
            "model_used": self.metadata["best_model_name"],
            "model_r2": round(self.metadata["best_model_r2"], 4),
            "prediction_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "status": status,
            "status_level": status_level,
            "inputs": cleaned,
        }


# Singleton instance - loaded once when the module is first imported
try:
    predictor = GroundwaterPredictor()
except FileNotFoundError:
    predictor = None
