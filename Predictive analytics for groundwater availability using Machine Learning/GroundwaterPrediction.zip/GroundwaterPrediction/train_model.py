"""
train_model.py
--------------
End-to-end Machine Learning training pipeline for the Groundwater
Prediction System.

Steps performed:
    1. Load Colorado_Groundwater.csv
    2. Handle missing values
    3. Remove duplicate rows
    4. Encode categorical variables (Label Encoding, stored for reuse)
    5. Feature scaling (StandardScaler)
    6. Train/Test split (80/20)
    7. Train multiple regression models:
         - Linear Regression
         - Random Forest Regressor
         - Decision Tree Regressor
         - Gradient Boosting Regressor
         - XGBoost Regressor (if installed)
    8. Compare all models on MAE, MSE, RMSE, R2
    9. Automatically select the best model (highest R2)
    10. Save best model, scaler, encoders, feature metadata and model
        comparison table to disk with joblib / json, so the Flask app
        can load them at runtime.

Run:
    python train_model.py
"""

import json
import warnings

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.tree import DecisionTreeRegressor

warnings.filterwarnings("ignore")

# Try to import XGBoost - it's an optional dependency per the requirements
try:
    from xgboost import XGBRegressor

    XGBOOST_AVAILABLE = True
except ImportError:
    XGBOOST_AVAILABLE = False

DATA_FILE = "Colorado_Groundwater.csv"
TARGET_COLUMN = "GroundwaterLevel_ft"

MODEL_FILE = "model.pkl"
SCALER_FILE = "scaler.pkl"
ENCODER_FILE = "encoder.pkl"
METADATA_FILE = "model_metadata.json"
COMPARISON_FILE = "model_comparison.json"


def load_data(path: str) -> pd.DataFrame:
    """Step 1: Load the dataset from disk."""
    print(f"Loading dataset from '{path}' ...")
    df = pd.read_csv(path)
    print(f"  -> Raw shape: {df.shape}")
    return df


def detect_column_types(df: pd.DataFrame, target: str):
    """Automatically detect numerical and categorical columns (excludes target)."""
    feature_df = df.drop(columns=[target])
    numeric_cols = feature_df.select_dtypes(include=[np.number]).columns.tolist()
    categorical_cols = feature_df.select_dtypes(exclude=[np.number]).columns.tolist()
    print(f"  -> Numeric columns   : {numeric_cols}")
    print(f"  -> Categorical columns: {categorical_cols}")
    return numeric_cols, categorical_cols


def handle_missing_values(df: pd.DataFrame, numeric_cols, categorical_cols) -> pd.DataFrame:
    """Step 2: Fill missing numeric values with median, categorical with mode."""
    df = df.copy()
    for col in numeric_cols:
        if df[col].isna().any():
            median_val = df[col].median()
            df[col] = df[col].fillna(median_val)
    for col in categorical_cols:
        if df[col].isna().any():
            mode_val = df[col].mode(dropna=True)
            fill_val = mode_val.iloc[0] if not mode_val.empty else "Unknown"
            df[col] = df[col].fillna(fill_val)
    print(f"  -> Missing values after cleanup: {int(df.isna().sum().sum())}")
    return df


def remove_duplicates(df: pd.DataFrame) -> pd.DataFrame:
    """Step 3: Remove duplicate rows."""
    before = len(df)
    df = df.drop_duplicates().reset_index(drop=True)
    after = len(df)
    print(f"  -> Removed {before - after} duplicate rows ({before} -> {after})")
    return df


def encode_categoricals(df: pd.DataFrame, categorical_cols):
    """Step 4: Label-encode categorical columns; keep encoders for reuse at inference time."""
    df = df.copy()
    encoders = {}
    for col in categorical_cols:
        le = LabelEncoder()
        df[col] = df[col].astype(str)
        df[col] = le.fit_transform(df[col])
        encoders[col] = le
        print(f"  -> Encoded '{col}' ({len(le.classes_)} unique categories)")
    return df, encoders


def evaluate_model(name, model, X_test, y_test):
    """Compute MAE, MSE, RMSE, R2 for a fitted model."""
    preds = model.predict(X_test)
    mae = mean_absolute_error(y_test, preds)
    mse = mean_squared_error(y_test, preds)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_test, preds)
    print(f"\n  Model: {name}")
    print(f"    MAE  : {mae:.4f}")
    print(f"    MSE  : {mse:.4f}")
    print(f"    RMSE : {rmse:.4f}")
    print(f"    R2   : {r2:.4f}")
    return {"name": name, "MAE": mae, "MSE": mse, "RMSE": rmse, "R2": r2}


def main():
    print("=" * 70)
    print("GROUNDWATER PREDICTION SYSTEM - MODEL TRAINING PIPELINE")
    print("=" * 70)

    # ---------- Step 1: Load ----------
    df = load_data(DATA_FILE)

    # ---------- Detect column types ----------
    print("\nDetecting column types ...")
    numeric_cols, categorical_cols = detect_column_types(df, TARGET_COLUMN)

    # ---------- Step 2: Handle missing values ----------
    print("\nHandling missing values ...")
    df = handle_missing_values(df, numeric_cols, categorical_cols)

    # ---------- Step 3: Remove duplicates ----------
    print("\nRemoving duplicate rows ...")
    df = remove_duplicates(df)

    # ---------- Step 4: Encode categorical variables ----------
    print("\nEncoding categorical variables ...")
    df_encoded, encoders = encode_categoricals(df, categorical_cols)

    # Final feature order (used consistently at inference time)
    feature_columns = numeric_cols + categorical_cols
    X = df_encoded[feature_columns]
    y = df_encoded[TARGET_COLUMN]

    # ---------- Step 5: Feature scaling ----------
    print("\nScaling numeric features (StandardScaler) ...")
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    # ---------- Step 6: Train/test split (80/20) ----------
    print("\nSplitting data into train (80%) / test (20%) sets ...")
    X_train, X_test, y_train, y_test = train_test_split(
        X_scaled, y, test_size=0.2, random_state=42
    )
    print(f"  -> Train shape: {X_train.shape}, Test shape: {X_test.shape}")

    # ---------- Step 7: Train multiple models ----------
    print("\nTraining models ...")
    models = {
        "Linear Regression": LinearRegression(),
        "Random Forest": RandomForestRegressor(
            n_estimators=120,
            max_depth=18,
            min_samples_leaf=2,
            random_state=42,
            n_jobs=-1,
        ),
        "Decision Tree": DecisionTreeRegressor(max_depth=12, random_state=42),
        "Gradient Boosting": GradientBoostingRegressor(
            n_estimators=200, learning_rate=0.1, max_depth=4, random_state=42
        ),
    }

    if XGBOOST_AVAILABLE:
        models["XGBoost"] = XGBRegressor(
            n_estimators=300,
            learning_rate=0.08,
            max_depth=6,
            subsample=0.9,
            colsample_bytree=0.9,
            random_state=42,
            n_jobs=-1,
            verbosity=0,
        )
    else:
        print("  -> XGBoost not installed, skipping (optional dependency).")

    # ---------- Step 8 & 9: Compare and select best model ----------
    results = []
    fitted_models = {}
    for name, model in models.items():
        model.fit(X_train, y_train)
        fitted_models[name] = model
        metrics = evaluate_model(name, model, X_test, y_test)
        results.append(metrics)

    results_sorted = sorted(results, key=lambda r: r["R2"], reverse=True)
    best_result = results_sorted[0]
    best_model_name = best_result["name"]
    best_model = fitted_models[best_model_name]

    print("\n" + "=" * 70)
    print("MODEL COMPARISON SUMMARY (sorted by R2, best first)")
    print("=" * 70)
    for r in results_sorted:
        print(
            f"{r['name']:<20} MAE={r['MAE']:.3f}  MSE={r['MSE']:.3f}  "
            f"RMSE={r['RMSE']:.3f}  R2={r['R2']:.4f}"
        )
    print(f"\nBEST MODEL: {best_model_name} (R2 = {best_result['R2']:.4f})")

    # ---------- Feature importance (if supported) ----------
    feature_importance = {}
    if hasattr(best_model, "feature_importances_"):
        importances = best_model.feature_importances_
        feature_importance = dict(
            sorted(
                zip(feature_columns, [float(i) for i in importances]),
                key=lambda x: x[1],
                reverse=True,
            )
        )
    elif hasattr(best_model, "coef_"):
        coefs = np.abs(best_model.coef_)
        feature_importance = dict(
            sorted(
                zip(feature_columns, [float(c) for c in coefs]),
                key=lambda x: x[1],
                reverse=True,
            )
        )

    # ---------- Step 11: Save best model + preprocessing artifacts ----------
    print("\nSaving artifacts to disk ...")
    joblib.dump(best_model, MODEL_FILE)
    joblib.dump(scaler, SCALER_FILE)
    joblib.dump(encoders, ENCODER_FILE)

    # Save metadata needed by the Flask app to build input forms & run inference
    metadata = {
        "target_column": TARGET_COLUMN,
        "numeric_columns": numeric_cols,
        "categorical_columns": categorical_cols,
        "feature_columns": feature_columns,
        "best_model_name": best_model_name,
        "best_model_r2": best_result["R2"],
        "best_model_mae": best_result["MAE"],
        "best_model_rmse": best_result["RMSE"],
        "feature_importance": feature_importance,
        "categorical_options": {
            col: encoders[col].classes_.tolist() for col in categorical_cols
        },
        "numeric_ranges": {
            col: {
                "min": float(df[col].min()),
                "max": float(df[col].max()),
                "mean": float(df[col].mean()),
            }
            for col in numeric_cols
        },
        "dataset_stats": {
            "rows": int(len(df)),
            "columns": int(df.shape[1]),
            "target_mean": float(df[TARGET_COLUMN].mean()),
            "target_min": float(df[TARGET_COLUMN].min()),
            "target_max": float(df[TARGET_COLUMN].max()),
            "target_std": float(df[TARGET_COLUMN].std()),
        },
    }
    with open(METADATA_FILE, "w") as f:
        json.dump(metadata, f, indent=2)

    with open(COMPARISON_FILE, "w") as f:
        json.dump(results_sorted, f, indent=2)

    print(f"  -> Saved {MODEL_FILE}, {SCALER_FILE}, {ENCODER_FILE}")
    print(f"  -> Saved {METADATA_FILE}, {COMPARISON_FILE}")
    print("\nTraining pipeline complete!")


if __name__ == "__main__":
    main()
